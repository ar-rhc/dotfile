#!/bin/bash

# Trigger the workspace update
/Users/zion/.config/sketchybar/plugins/aerospace_workspaces.sh

# Also trigger a sketchybar update
sketchybar --trigger aerospace_workspace_change