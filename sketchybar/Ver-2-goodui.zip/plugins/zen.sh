#!/bin/bash

# Simple zen script - toggles between 12h and 24h format
# You can customize this to do whatever you want when clicking the clock

# For now, just open the Calendar app
open -a Calendar