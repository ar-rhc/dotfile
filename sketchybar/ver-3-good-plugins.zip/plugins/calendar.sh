#!/bin/bash

sketchybar --set $NAME label="$(date +'%a %b %d %I:%M%p')"
