#!/bin/bash

sketchybar --set $NAME label="$(date +'%I:%M %p')"

