sketchybar --add item topproc right \
           --set topproc drawing=off \
                         label.padding_right=10 \
                         update_freq=15 \
                         script="$PLUGIN_DIR/topproc.sh"