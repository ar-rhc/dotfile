import { React, run } from "uebersicht";

const LAUNCH_BUTTONS = [
  // TEST BUTTON - Click this first to verify commands work!
   { id: 'calendar', command: "open '/System/Applications/Calendar.app'" },
  { id: 'notes', command: "open '/System/Applications/Notes.app'" },
  { id: 'mail', command: "open '/System/Applications/Mail.app'" },
  { id: 'maps', command: "open '/System/Applications/Maps.app'" },
  { id: 'photos', command: "open '/System/Applications/Photos.app'" },
  // Add more buttons here with their IDs and commands
  { id: 'safari', command: "open '/System/Applications/Safari.app'" },
  { id: 'messages', command: "open '/System/Applications/Messages.app'" },
  { id: 'music', command: "open '/System/Applications/Music.app'" },
  { id: 'finder', command: "open '/System/Library/CoreServices/Finder.app'" },
  { id: 'settings', command: "open '/System/Applications/System Settings.app'" },
  { id: 'settings', command: "open '/System/Applications/System Settings.app'" }
];

const PLACEHOLDER_COUNT = 14; // Reduced since we have more launch buttons now

const COLORS = ['#FC635E', '#FDBE41', '#35CD4B', '#3F51B5', '#9C27B0'];

export const command = '';
export const refreshFrequency = 30000;

export const render = () => {
  const placeholders = Array.from({ length: PLACEHOLDER_COUNT }, (_, index) => {
    const actualIndex = index + LAUNCH_BUTTONS.length;
    
    return (
      <li 
        key={`placeholder-${index}`}
        className="button"
        style={{
          backgroundColor: COLORS[actualIndex % 5]
        }}
      />
    );
  });

  return (
    <div style={{
      position: 'fixed',
      right: '120px',
      bottom: '6px'
    }}>
      {/* Debug indicator - remove this once everything works */}
      <div style={{
        position: 'absolute',
        top: '-30px',
        right: '0',
        fontSize: '10px',
        color: '#00FF00',
        backgroundColor: 'rgba(0,0,0,0.7)',
        padding: '2px 5px',
        borderRadius: '3px',
        fontFamily: 'monospace'
      }}>
        Widget Loaded - Click red button to test
      </div>
      <style>{`
        .button {
          width: 26px;
          height: 26px;
          margin: 2px;
          padding: 0;
          display: inline-block;
          border-radius: 2px;
          box-shadow: 0 -3px rgba(0, 0, 0, 0.2) inset;
          transition: all 0.2s ease;
          transform: scale(1);
          position: relative;
          opacity: 0.9;
          box-sizing: border-box;
        }
        
        .button:hover {
          transform: scale(1.6);
          z-index: 10;
          opacity: 1;
        }
        
        .button[data-launch-command] {
          cursor: pointer;
          pointer-events: auto;
        }
        
        .button:not([data-launch-command]) {
          pointer-events: none;
        }
      `}</style>
      <ul style={{
        padding: '3px 3px 0 3px',
        borderRadius: '3px',
        width: 'auto',
        listStyle: 'none',
        display: 'grid',
        gridTemplateColumns: 'repeat(5, max-content)',
        gap: '4px',
        margin: 0,
        transform: 'scale(0.6)'
      }}>
        {LAUNCH_BUTTONS.map(({ id, command, test }, index) => {
          return (
            <li
              key={id}
              id={id}
              className="button"
              data-launch-command={command}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                if (test) {
                  run("osascript -e 'display notification \"Test button clicked!\" with title \"Widget Test\"'");
                }
                run(command)
                  .then(() => {
                    if (test) {
                      console.log('Command executed successfully:', command);
                    }
                  })
                  .catch((err) => {
                    console.error('Error executing command:', err);
                  });
              }}
              style={{
                backgroundColor: test ? '#FF0000' : COLORS[index % 5],
                border: test ? '2px solid #FFFF00' : 'none'
              }}
            />
          );
        })}
        {placeholders}
      </ul>
    </div>
  );
};

export const afterRender = function(domEl) {
  // Show notification that widget is ready
  setTimeout(() => {
    run("osascript -e 'display notification \"Widget ready! Click red button to test.\" with title \"Grid Launcher\"'")
      .catch(() => {
        // Ignore errors in notification
      });
  }, 500);
  
  // Also set up jQuery handlers as backup (in case onClick doesn't work)
  if (domEl && typeof $ !== 'undefined') {
    LAUNCH_BUTTONS.forEach(({ id, command, test }) => {
      $(domEl).on('click', `#${id}`, () => {
        if (test) {
          run("osascript -e 'display notification \"Test button clicked (jQuery)!\" with title \"Widget Test\"'");
        }
        run(command).catch((err) => {
          console.error('Error executing command:', err);
        });
      });
    });
  }
};